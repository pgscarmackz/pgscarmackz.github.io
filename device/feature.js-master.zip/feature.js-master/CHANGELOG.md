# v1.1.1 (2019-11-19)

- Fixes “Access is denied for this document” bug.
- Updates all dependencies.
- Update to Gulp 4.x.

# v1.1.0 (2019-06-11)

- Makes it possible to extend the library with your own tests.
- Bug fixes and feature improvements.
- Adds tests.

# v1.0.1 (2016-01-31)

- Optimization.
- Add gulp build task.
- Add NPM support.

# v1.0.0 (2016-01-09)

- Initial release.
