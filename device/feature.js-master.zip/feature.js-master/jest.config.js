module.exports = {
  browser: true,
  setupFiles: [
    'jest-canvas-mock'
  ]
};
